//https://youtu.be/ZdRjXWJNLrQ?si=Cicxp7aRZC7_5kre
//vídeo trailer 
var df;
//cordenada do bottao
var xbt1, ybt1, xbt2, ybt2, xbt3, ybt3, xcu, ycu,sele;
//preload
var img, ft, sel, cu, rum, eu,cru, tiro,boss,vid,fim,raio,hp,m2,m1,m3,atk,rat;
//var jogo
var vida, vidam, poder,ganhar,lingua,calma;
//var inimigos
var inimigos = [];
var numInimigos = 5;
var tempoParaNovoInimigo = 60;
var tempoUltimoInimigo = 0;
var ninas=[355,315,275,235,195]

class Inimigo {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    if(df==13){
      this.speed = 3; // Velocidade do inimigo
    }
    else if(df==15){
      this.speed = 4; // Velocidade do inimigo
    }
    
    this.size = 40; // Tamanho do inimigo
  }

  // Atualiza a posição do inimigo
  update() {
    this.x -= this.speed;
  }

  // Desenha o inimigo na tela
  display() {
     if(df==13){
       
     
    image(tiro,this.x, this.y-17, this.size, this.size); }
    else  if(df==15){
       
     
    image(cru,this.x, this.y-17, this.size, this.size); }
  }

  // Verifica colisão com o personagem
  collidesWith(px, py, psize) {
    let distance = dist(this.x, this.y, px, py);
    return distance < (this.size / 2 + psize / 2);
  }
}
function criarInimigo() {
  let y = random([195, 235, 275, 315, 355]);
  let x = 375
  let novoInimigo = new Inimigo(x, y);
  inimigos.push(novoInimigo);
}
function preload() {
  rat = loadImage("dorime.png")
  tiro = loadImage("tiro.png")
  eu = loadImage("eu.jpeg")
  sel = loadImage("pixilart.png");
  rum = loadImage("mumeri.jpeg");
  img = loadImage("tinygame.png");
  ft = loadFont("PixelifySans-Regular.ttf");
  boss = loadImage('sapo.png');
  vid = loadImage('vida.png');
  fim = loadImage('fim.png');
  hp = createAudio("hp.mp3");
  dano = createAudio("dano.mp3");
  m2 = createAudio("inicio.mp3");
  m1 = createAudio("musica.mp3");
  cru = loadImage('cru.png')
   atk = loadImage("dan.png")
  m3 = createAudio("b2.mp3");
}
function setup() {
  createCanvas(500, 400);
  xbt1 = 200;
  ybt1 = 190;
  xbt2 = 185;
  ybt2 = 250;
  xbt3 = 173;
  ybt3 = 300;
  xcu = 250;
  ycu = 205;
  sele=170
  df = 1

    ganhar =2
 
    ganha =4

  calma=0
  //jogo
  vida = 3;
  vidam = 50;
  poder = 10;
  xpr = 125;
  ypr = 195;
  kl = 0
  kr = 0
  lingua=0
}

function draw() {
  if (df == 1) {
    menu();
  } else if (df == 13) {
    iniciar();
  } else if (df == 2) {
    selecao()
  }
    else if (df == 3) {
    creditos();
  } else if (df == 4) {
    cojar();
  }
   else if (df == 5) {
   background(fim);
  }
    else if (df == 15) {
  b2();
  }
}
function keyPressed() {
  // controle do menu
  if(df == 1){
  if(keyCode==UP_ARROW || key == 'w'){
    if(ycu == ybt1 + 15){
       ycu = ybt3 + 15;
    }
     else if(ycu == ybt2 + 15){
       ycu = ybt1 + 15;
    }
    else if(ycu == ybt3 + 15){
       ycu = ybt2 + 15;
     
     }}
  if(keyCode==DOWN_ARROW || key == 's'){
    if(ycu == ybt1 + 15){
       ycu = ybt2 + 15;
    }
     else if(ycu == ybt2 + 15){
       ycu = ybt3 + 15;
    }
    else if(ycu == ybt3 + 15){
       ycu = ybt1 + 15;
     
     }}
  if (keyCode == ENTER && ycu == ybt1 + 15) {
    df = 2;
  }
  else if (keyCode == ENTER && ycu == ybt2 + 15) {
    df = 3;
  }     else if (keyCode == ENTER && ycu == ybt3 + 15) {
    df = 4;
  }
  }  
  if (keyCode == BACKSPACE) {
    df = 1;
  }
  if(df == 13||df == 15){
    if(keyCode == DOWN_ARROW || key == 's'){
      if(ypr == 195){
        ypr = 235;
        poder++
      }
      else if(ypr == 235){
        ypr = 275;
        poder++
      }
      else if(ypr == 275){
        ypr = 315;
        poder++
      }
      else if(ypr == 315){
        ypr = 355;
        poder++
      }
    }
    if(keyCode == UP_ARROW || key == 'w'){
      if(ypr == 355){
        ypr = 315;
        poder++
      }
      else if(ypr == 315){
        ypr = 275;
        poder+=10
      }
      else if(ypr == 275){
        ypr = 235;
        poder+=10
      }
      else if(ypr == 235){
        ypr = 195;
        poder++
      }
    }
    if(keyCode ==LEFT_ARROW || key == 'a'){
      kl = 1
       if (xpr >= 125) xpr-=10;
       }
    if(keyCode == RIGHT_ARROW || key == 'd'){
      kr = 1
      if (xpr <= 360) xpr+=10;
      }
  } 
  if(df==2){
      if(keyCode == RIGHT_ARROW){
        if(sele==170){
          sele=280
} 
 else if(sele==280){
          sele=170
}
      }
     if(keyCode == LEFT_ARROW){
        if(sele==280){
          sele=170
} 
 else if(sele==170){
          sele=280
}
      }
    if(keyCode == DOWN_ARROW && sele== 170){
       df=13
       }
    else if(keyCode == DOWN_ARROW && sele==280){
       df=15
       }
  }
}
function menu() {
  background(img);
 fill("red")
  image(sel, xcu-40, ycu-25, 70, 60);

  fill("#04050800");
  rect(xbt1, ybt1, 90, 25);

  rect(xbt2, ybt2, 130, 25);

  rect(xbt3, ybt3, 155, 26);
      vida = 3
  
    vidam = 50
 
    ganhar = 2
  
  inimigos = [];
  poder = 0
  lingua = 0
  m2.stop ()
  m3.stop()
  m1.loop()
 }
function iniciar() {
  background(0)
  background(20);
  image(boss,80,-50,320,320)
 m1.stop ()
  m3.stop()
  m1.loop()
  fill('purple')
  rect(30, 200, 20, 100)
  
  fill('black')
  rect(30, 200, 20, 100- poder /* pontos*/)
  if(poder<=0){
    poder = 0;
  }
  
  fill('rgb(72,0,72)')
  rect(125, 147, 280, 250)
  
  
  
  //linhas
  fill("rgb(210,198,198)")
  rect(125, 355, 280, 3)
  rect(125, 315, 280, 3)
  rect(125, 275, 280, 3)
  rect(125, 235, 280, 3)
  rect(125, 195, 280, 3)
  //atk extra
  text(round((millis()/1000), 0), 50, 50);
  if(lingua){
   
  
    fill("red")
    rect(125,ninas[calma],280,3)
    if(ypr==ninas[calma]){
      poder-=1
    }
  }
  if(round((millis()/1000), 0) %8 == 0 && lingua==0){
     lingua=1
     calma= round(Math.random()*4 , 0);
    console.log()
     }
  else if(round((millis()/1000), 0) %16 == 0 &&lingua==1){
    lingua=0
   // fill("rgb(210,198,198)")
    //rect(125,ninas[calma],280,3)
  }
  //vida da aranha
  if(vida==3){
    
  
image(vid,1,310,40,40)
  image(vid,33,310,40,40)
    image(vid,65,310,40,40)
  }
   else if(vida==2){
    
  image(vid,1,310,40,40)
  image(vid,33,310,40,40)
    }
  
  
   else {
    
  image(vid,1,310,40,40)
   }
  // Atualiza e desenha os inimigos
  for (let i = inimigos.length - 1; i >= 0; i--) {
    let inimigo = inimigos[i];
    inimigo.update();
    inimigo.display();
    if (inimigo.collidesWith(xpr-10, ypr+10, 17)) {
      inimigos.splice(i, 1); 
      vida--; 
     if(hp.play(1)){
       hp.stop(1)
     }
       hp.play(1);
      
      //tela do fim
      if (vida <= 0) {
       setup()  
       df = 5; 
       
      }
    }
    // Remove inimigos que saíram da tela
    if (inimigo.x < 125) {
      inimigos.splice(i, 1);
    }
  }
   while (inimigos.length < numInimigos) {
    criarInimigo();
  }

  // Cria um novo inimigo periodicamente
  tempoUltimoInimigo++;
  if (tempoUltimoInimigo >= tempoParaNovoInimigo) {
    criarInimigo();
    tempoUltimoInimigo = 0; // Reseta o contador de tempo
  }  
  
  image(sel, xpr , ypr - 15, 30, 30)
  if(poder >= 100){
    poder = 0
    ganhar--
    dano.play();
      image(atk,210,15,80,140)

    console.log(poder)
    console.log(ganhar)
  } else {
    // asd
  }
  if (ganhar==0){
        vida = 3
    vidam = 50
    ganhar = 2
    df=3
    inimigos = [];
    poder = 0
    lingua = 0
  }
  if(df == 13) {
    if (kl == 1) {
      if (xpr >= 125) xpr-=3;
    }
    if (kr == 1) {
      if (xpr <= 375) xpr+=3;
    }
  }
}
function creditos() {
  background(0)
  background(rum);
  image(eu, 10,300,60,60)
  textSize(40);
  textFont(ft);
  fill("rgb(192,11,11)");
  text("obrigado por jogar", 60, 40);
  textSize(25);
   text("progamação e desenvolvimento", 100, 100);
  text("erick ezequiel, mateus gurgel,", 100, 130);
  text("de lima gurgel", 100, 150);
   text("apoio restante", 180, 188);
text("Italo, Thales, Toby fox", 100, 208);
  triangle(10, 35, 50, 20, 50, 47);
}
function cojar() {
  background(0)
 background("rgb(76,72,72)");
  textSize(40);
  textFont(ft);
  fill("rgb(190,72,190)");
  text("CONTROLE A ARANHA",90, 50);
  triangle(10, 35, 50, 20, 50, 47);
    textSize(15);
  text("clique com as setas direcionais ou wasd",10, 150);
   text("para mover para cima, baixo, direita e esquerda",10, 170);
   text("desvie usando as teias para evitarde ser exorcizado",10, 190);
  textSize(15);
  text("",260, 150);
   text("sofre um desequilíbrio entre cargas positivas e negativas",10, 270);
   text("friccionar nas teias gera eletricidade estática que é",10, 210);
  text("No material isolante,ele é eletrizado, ou seja, de alguma forma ",10,250)
  text("o fenômeno de acumulação de cargas elétricas em um material .",10,230)
  fill("purple")
}
function selecao (){
   background(0)
  background(2);
  image(boss, 90,130,200,200)
  image(rat, 250,150,100,100)
  image(vid, sele, 175, 50, 55);
m1.stop()
  textSize(40);
  textFont(ft);
  
   fill("#04050800");
  rect(150, 160,80, 100);

  rect(255, 150, 100, 110);
fill("rgb(192,11,11)");
  text("clique baixo pra lutar", 60, 40);
  /*textSize(25);
   text("progamação e desenvolvimento", 100, 100);
  text("erick ezequiel, mateus gurgel,", 100, 130);
  text("de lima gurgel", 100, 150);
   text("apoio restante", 180, 188);
text("Italo, Thales, Toby fox", 100, 208);*/
  triangle(10, 35, 50, 20, 50, 47);
  
}
function b2() {
  background(0)
  background(20);
  image(rat,160,-20,170,170)
  m1.stop ()
  m2.stop()
  m3.loop()
  fill('purple')
  rect(30, 200, 20, 100)
  
  fill('black')
  rect(30, 200, 20, 100- poder /* pontos*/)
  if(poder<=0){
    poder = 0;
  }
  
  fill('rgb(72,0,72)')
  rect(125, 147, 280, 250)
  
  
  
  //linhas
  fill("rgb(210,198,198)")
  rect(125, 355, 280, 3)
  rect(125, 315, 280, 3)
  rect(125, 275, 280, 3)
  rect(125, 235, 280, 3)
  rect(125, 195, 280, 3)
  //atk extra
 
  //vida da aranha
  if(vida==3){
    
  
image(vid,1,310,40,40)
  image(vid,33,310,40,40)
    image(vid,65,310,40,40)
  }
   else if(vida==2){
    
  image(vid,1,310,40,40)
  image(vid,33,310,40,40)
    }
  
  
   else {
    
  image(vid,1,310,40,40)
   }
  // Atualiza e desenha os inimigos
  for (let i = inimigos.length - 1; i >= 0; i--) {
    let inimigo = inimigos[i];
    inimigo.update();
    inimigo.display();
    if (inimigo.collidesWith(xpr-10, ypr+10, 17)) {
      inimigos.splice(i, 1); 
      vida--; 
     if(hp.play(1)){
       hp.stop(1)
     }
       hp.play(1);
      
      //tela do fim
      if (vida <= 0) {
       setup()  
       df = 5; 
       
      }
    }
    // Remove inimigos que saíram da tela
    if (inimigo.x < 125) {
      inimigos.splice(i, 1);
    }
  }
   while (inimigos.length < numInimigos) {
    criarInimigo();
  }

  // Cria um novo inimigo periodicamente
  tempoUltimoInimigo++;
  if (tempoUltimoInimigo >= tempoParaNovoInimigo) {
    criarInimigo();
    tempoUltimoInimigo = 0; // Reseta o contador de tempo
  }  
  
  image(sel, xpr , ypr - 15, 30, 30)
  if(poder >= 100){
    poder = 0
    ganha--
    dano.play();
      image(atk,210,15,100,140)

    console.log(poder)
    console.log(ganhar)
  } else {
    // asd
  }
  if (ganha==0){
        vida = 3
    vidam = 50
    ganha = 4
    df=3
    inimigos = [];
    poder = 0
    lingua = 0
  }
  if(df == 15) {
    if (kl == 1) {
      if (xpr >= 125) xpr-=3;
    }
    if (kr == 1) {
      if (xpr <= 375) xpr+=3;
    }
  }
}
function keyReleased() {
  if(df == 13|| df==15) {
    if (keyCode == LEFT_ARROW || key == 'a') {
      
      kl = 0;
    }
    if (keyCode == RIGHT_ARROW || key == 'd') {
      
      kr = 0;
    }
  }
} 
function mouseClicked (){
  if(df==3||df==4||df==2){
    if(mouseX>10&&mouseX<50 &&mouseY>20&&mouseY<47){
      df=1
      }
  }
}
//https://youtu.be/ZdRjXWJNLrQ?si=Cicxp7aRZC7_5kre
//vídeo trailer 